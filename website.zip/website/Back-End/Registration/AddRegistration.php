<?php

?>
<?php
include_once("RegistrationModel.php");
$ObjUser = new Registration;
$ObjUser->setSid($_POST["Sid"]);
$ObjUser->setPStatus($_POST["PStatus"]);
$ObjUser->setDay($_POST["Day"]);
$ObjUser->setTime($_POST["Time"]);
$ObjUser->Store();
header("location:Registration.php");

?>